$base = "C:\ProgramData\SysAgent"
$queue = "$base\Queue"
$log = "$base\log"

New-Item -ItemType Directory -Force -Path $queue | Out-Null
New-Item -ItemType Directory -Force -Path $log | Out-Null

# ================================
# NEXTCLOUD CREDENTIAL
# ================================

$credPath = "$base\cred.json"
$credData = Get-Content $credPath | ConvertFrom-Json

$user = $credData.username
$pass = $credData.password

$securePass = ConvertTo-SecureString $pass -AsPlainText -Force
$cred = New-Object System.Management.Automation.PSCredential ($user,$securePass)

# ================================
# DEVICE BASIC INFO
# ================================

$hostname = $env:COMPUTERNAME
$os = (Get-CimInstance Win32_OperatingSystem).Caption
$serial = (Get-CimInstance Win32_BIOS).SerialNumber
$cpu = (Get-CimInstance Win32_Processor).Name

$currentUser = (Get-CimInstance Win32_ComputerSystem).UserName

# ================================
# CPU / RAM
# ================================

$totalRAM = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB,2)
$ramFree = [math]::Round((Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory/1MB,2)
$ramUsed = [math]::Round($totalRAM - $ramFree,2)

$cpuLoad = (Get-Counter '\Processor(_Total)\% Processor Time').CounterSamples.CookedValue
$cpuLoad = [math]::Round($cpuLoad,2)

# ================================
# DEVICE UPTIME
# ================================

$lastBoot = (Get-CimInstance Win32_OperatingSystem).LastBootUpTime
$uptime = (Get-Date) - $lastBoot

$uptimeInfo = @{
    last_boot = $lastBoot
    uptime_hours = [math]::Round($uptime.TotalHours,2)
}

# ================================
# BATTERY INFO (LAPTOP)
# ================================

$batteryInfo = @{
    present = $false
}

$battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue

if($battery){

$batteryInfo = @{
    present = $true
    charge_percent = $battery.EstimatedChargeRemaining
    status = $battery.BatteryStatus
}

}

# ================================
# DISK INFORMATION
# ================================

$disks = @()

Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {

$total = [math]::Round($_.Size/1GB,2)
$free = [math]::Round($_.FreeSpace/1GB,2)
$used = [math]::Round($total-$free,2)

$disks += [PSCustomObject]@{

drive = $_.DeviceID
filesystem = $_.FileSystem
total_gb = $total
used_gb = $used
free_gb = $free

}

}

# ================================
# NETWORK INTERFACES
# ================================

$networkInterfaces = @()
$vpnDetected = $false

$adapters = Get-NetAdapter -ErrorAction SilentlyContinue

foreach ($adapter in $adapters) {

$ipInfo = Get-NetIPAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where {$_.IPAddress -notlike "169.*"}

$gateway = (Get-NetRoute -InterfaceIndex $adapter.ifIndex -DestinationPrefix "0.0.0.0/0" -ErrorAction SilentlyContinue | Select -First 1).NextHop

$dns = (Get-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).ServerAddresses

$dhcp = (Get-NetIPInterface -InterfaceIndex $adapter.ifIndex -ErrorAction SilentlyContinue).Dhcp

# VPN detection
if($adapter.InterfaceDescription -match "VPN|TAP|TUN|WireGuard|OpenVPN|Fortinet|Cisco"){

$vpnDetected = $true

}

$networkInterfaces += [PSCustomObject]@{

name = $adapter.Name
description = $adapter.InterfaceDescription
mac = $adapter.MacAddress
status = $adapter.Status
link_speed = $adapter.LinkSpeed

ip = $ipInfo.IPAddress
gateway = $gateway
dns_servers = $dns
dhcp_enabled = $dhcp

}

}

# ================================
# PUBLIC IP + ISP
# ================================

$publicNetwork = @{
    ip = $null
    isp = $null
    country = $null
    city = $null
}

try{

$geo = Invoke-RestMethod "http://ip-api.com/json"

$publicNetwork.ip = $geo.query
$publicNetwork.isp = $geo.isp
$publicNetwork.country = $geo.country
$publicNetwork.city = $geo.city

}catch{}

# ================================
# SOFTWARE LIST
# ================================

$paths = @(
"HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",
"HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"
)

$software = foreach ($path in $paths) {

Get-ItemProperty $path -ErrorAction SilentlyContinue |
Where {$_.DisplayName} |
ForEach-Object {

$size = ""

if ($_.EstimatedSize) {
$size = "{0:N1} MB" -f ($_.EstimatedSize/1024)
}

$installDate = ""

if ($_.InstallDate) {
try{
$installDate = [datetime]::ParseExact($_.InstallDate,'yyyyMMdd',$null).ToString("yyyy-MM-dd")
}catch{}
}

[PSCustomObject]@{

Name = $_.DisplayName
Publisher = $_.Publisher
InstalledOn = $installDate
Size = $size
Version = $_.DisplayVersion

}

}

}

# ================================
# BUILD JSON
# ================================

$data = @{

hostname = $hostname
serial = $serial
os = $os

user_logged = $currentUser

cpu = $cpu
cpu_load_percent = $cpuLoad

ram_total_gb = $totalRAM
ram_used_gb = $ramUsed
ram_free_gb = $ramFree

uptime = $uptimeInfo

battery = $batteryInfo

disks = $disks

network_interfaces = $networkInterfaces

vpn_detected = $vpnDetected

public_network = $publicNetwork

software = $software

timestamp = (Get-Date)

}

$json = $data | ConvertTo-Json -Depth 6

$file = "$queue\$hostname-$(Get-Date -Format 'yyyyMMddHHmmss').json"

$json | Out-File $file -Encoding UTF8

# ================================
# INTERNET CHECK
# ================================

$internet = Test-Connection 8.8.8.8 -Count 1 -Quiet

if ($internet) {

$nextcloud = "https://cloud.jpc.co.id/remote.php/dav/files/sysmonitoring/INV-SOFTWARE-MONITORING"

Get-ChildItem $queue | ForEach-Object {

$upload = "$nextcloud/$($_.Name)"

try{

Invoke-WebRequest `
-Uri $upload `
-Method Put `
-InFile $_.FullName `
-Credential $cred `
-UseBasicParsing

Remove-Item $_.FullName

}catch{

$_ | Out-File "$log\upload_error.txt" -Append

}

}

}